import PricingFaq from "../components/pricing/PricingFaq";
function Pricing() {
	return (
		<>
			
			<PricingFaq />
		</>
	);
}

export default Pricing;
