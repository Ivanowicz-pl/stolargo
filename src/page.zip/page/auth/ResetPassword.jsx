import ResetForm from "../../components/auth/ResetForm";
function ResetPassword() {
	return (
		<>
			<ResetForm />
		</>
	);
}

export default ResetPassword;
